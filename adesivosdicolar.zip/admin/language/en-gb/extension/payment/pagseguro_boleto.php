<?php

// Heading
$_['heading_title'] = 'PagSeguro Checkout Transparente (Boleto)';

// Text
$_['text_pagseguro_boleto'] = '<a href="https://valdeir.dev"><img src="/admin/view/image/payment/pagseguro.png" /></a>';
