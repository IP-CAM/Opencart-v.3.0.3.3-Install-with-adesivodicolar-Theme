<?php

// Heading
$_['heading_title'] = 'PagSeguro Checkout Transparente (Cartão de Débito)';

// Text
$_['text_pagseguro_debit'] = '<a href="https://valdeir.dev"><img src="/admin/view/image/payment/pagseguro.png" /></a>';
