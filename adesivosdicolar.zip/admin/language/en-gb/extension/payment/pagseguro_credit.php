<?php

// Heading
$_['heading_title'] = 'PagSeguro Checkout Transparente (Cartão de Crédito)';

// Text
$_['text_pagseguro_credit'] = '<a href="https://valdeir.dev"><img src="/admin/view/image/payment/pagseguro.png" /></a>';
